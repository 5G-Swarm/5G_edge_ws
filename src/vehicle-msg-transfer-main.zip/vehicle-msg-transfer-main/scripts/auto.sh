cd ../../../
source devel/setup.bash
cd src/ros-vehicle-transfer/scripts
